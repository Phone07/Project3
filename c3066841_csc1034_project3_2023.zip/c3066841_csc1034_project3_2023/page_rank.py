import random
import sys
import os
import time
import argparse


# Function to load the graph from the school_web file

def load_graph(args):
    graph = {}
    for line in args.datafile:
        node, target = line.split()
        if node not in graph:
            graph[node] = []
        graph[node].append(target)  # Appending the target node to the list of adjacent nodes for the current node
    return graph


# The function to print statistics about the loaded graph

def print_stats(graph):
    num_nodes = len(graph)
    num_edges = sum(len(adjacent_nodes) for adjacent_nodes in graph.values())
    print(f"Number of nodes: {num_nodes}")  # Printing the total number of nodes in the graph
    print(f"Number of edges: {num_edges}")  # Printing the total number of edges in the graph


# Stochastic page rank algorithms by importing random
def stochastic_page_rank(graph, args):
    hit_count = {node: 0 for node in graph}  # Initializing a dictionary to count hits for each node
    current_node = random.choice(list(graph.keys()))  # Starting from a random node in the graph
    hit_count[current_node] += 1  # Incrementing hit count for the starting node
    for _ in range(args.repeats):
        if not graph[current_node]:  # If the current node has no adjacent nodes
            current_node = random.choice(list(graph.keys()))  # Choosing a new random node
        else:
            next_node = random.choice(graph[current_node])
            current_node = next_node

        hit_count[current_node] += 1  # Increasing hit count for the current node
    return hit_count


# Distribution-based page rank algorithm
def distribution_page_rank(graph, args):
    num_nodes = len(graph)
    node_prob = {node: 1 / num_nodes for node in graph}  # Initializing probabilities for each node
    for _ in range(args.steps):
        new_prob = {node: 0 for node in graph}  # Initializing new probabilities for each node in this step

        for node in graph:
            out_degree = len(graph[node])
            p = node_prob[node] / out_degree if out_degree > 0 else 0  # Calculate the probability

            for target in graph[node]:
                new_prob[target] += p  # Accumulating probability for each target node

        node_prob = new_prob  # New node probabilities for the next step
    return node_prob


# Argument parsing setups
parser = argparse.ArgumentParser(description="Estimates page ranks from link information")
parser.add_argument('datafile', nargs='?', type=argparse.FileType('r'), default=sys.stdin,
                    help="Textfile of links among web pages as URL tuples")
parser.add_argument('-m', '--method', choices=('stochastic', 'distribution'), default='stochastic',
                    help="selected page rank algorithm")
parser.add_argument('-r', '--repeats', type=int, default=1_000_000, help="number of repetitions")
parser.add_argument('-s', '--steps', type=int, default=100, help="number of steps a walker takes")
parser.add_argument('-n', '--number', type=int, default=20, help="number of results shown")

if __name__ == '__main__':
    args = parser.parse_args()
    algorithm = distribution_page_rank if args.method == 'distribution' else stochastic_page_rank

    graph = load_graph(args)

    print_stats(graph)

    start = time.time()
    ranking = algorithm(graph, args)
    stop = time.time()
    time = stop - start

    top = sorted(ranking.items(), key=lambda item: item[1], reverse=True)
    sys.stderr.write(f"Top {args.number} pages:\n")
    print('\n'.join(f'{100 * v:.2f}\t{k}' for k, v in top[:args.number]))
    sys.stderr.write(f"Calculation took {time:.2f} seconds.\n")
